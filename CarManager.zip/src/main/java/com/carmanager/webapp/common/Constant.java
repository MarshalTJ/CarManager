package com.carmanager.webapp.common;

public class Constant {
	public static String SESSION_COMPANY_USER="SESSION_COMPANY_USER";
	
	public static String SESSION_COMPANY_PC="SESSION_COMPANY_PC";
	
	public static String SESSION_WECHAT_SHOP="SESSION_WECHAT_SHOP";
	
	public static String SESSION_WECHAT_CUSTOMER="SESSION_WECHAT_CUSTOMER";
	
	public static String SESSION_WECHAT_FUNS="SESSION_WECHAT_FUNS";

}
