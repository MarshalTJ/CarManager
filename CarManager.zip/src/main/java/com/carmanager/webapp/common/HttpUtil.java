package com.carmanager.webapp.common;

import com.alibaba.fastjson.JSONObject;

public class HttpUtil {

	public static JSONObject httpsRequest(String url, String string, Object object) {
		// TODO Auto-generated method stub
		return null;
	}

}
