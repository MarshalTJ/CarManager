package com.carmanager.webapp.customer.bean;

public class Customer {

}
