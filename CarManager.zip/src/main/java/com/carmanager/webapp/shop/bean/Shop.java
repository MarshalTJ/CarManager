package com.carmanager.webapp.shop.bean;

public class Shop {

}
