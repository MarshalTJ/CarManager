package com.carmanager.webapp.shop.service;

import com.carmanager.webapp.shop.bean.Shop;

public interface ShopService {
    public Shop findShopById(Long id);
}
