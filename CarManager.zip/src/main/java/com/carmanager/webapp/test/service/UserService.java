package com.carmanager.webapp.test.service;

import com.carmanager.webapp.test.bean.User;

/**
 * Created by Administrator on 2016/3/27.
 */
public interface UserService {
    public User getUserById(int id);

}
